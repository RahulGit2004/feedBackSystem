package Feedback_System.service;

import Feedback_System.model.Batch;
import Feedback_System.model.User;
import Feedback_System.service.impl.BatchServiceImpl;

import java.util.List;

public interface UserService {

    boolean signUp(String username, String password, String phone, String role);
    boolean signIn(String username, String pass);
    List<User> userList();
    Batch findStudentByBatch(String studentPhone, String batchName, BatchServiceImpl batchService);

    String getUserRole(String name, String phone);

    String getBatchByUsernameAndPassword(String username, String password);

    void showMyBatchmates(String username, String password);
}
