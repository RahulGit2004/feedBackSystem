package Feedback_System.service.impl;

import Feedback_System.model.Batch;
import Feedback_System.model.User;
import Feedback_System.repository.repository.impl.UserRepoImpl;
import Feedback_System.service.UserService;

import java.util.List;

public class UserServiceImpl implements UserService {
    UserRepoImpl userRepo = new UserRepoImpl();
    BatchServiceImpl batchService = new BatchServiceImpl();

    public boolean signUp(String username, String password, String phone, String role) {

        User user = new User(username, password, phone, role);
        userRepo.saveStudent(user);

        return true;

    }


    @Override
    public boolean signIn(String username, String pass) {
        User user = userRepo.findUser(username, pass);
        if (user != null) {
            return true;
        }
        return false;
    }

    @Override
    public List<User> userList() {
        List<User> users = userRepo.userList();
        for (User user : users) {
            System.out.println(user.getRole() + " " + user.getPhoneNumber());
        }
        return users;
    }

    @Override
    public Batch findStudentByBatch(String studentPhone, String batchName, BatchServiceImpl batchService) {
        // issue is a student able to give feedback of any batch.
//        User isStudent = studentRepo.existsStudent(studentPhone);  //  this is able to solve my feedback
//        Batch studentInBatch = batchService.batchRepo.checkBatch(batchName);  // but above problem arrived.
        Batch student = batchService.batchRepo.isStudentByBatch(batchName,studentPhone);
        if (student != null) {
            return student;
        }
        return null;
    }


    @Override
    public String getUserRole(String name, String phone) {
        return userRepo.getRole(name, phone);
    }

    @Override
    public String getBatchByUsernameAndPassword(String username, String password) {
        return batchService.getBatchByUsernameAndPassword(username , password);
    }

    @Override
    public void showMyBatchmates(String username, String password) {
        batchService.showMyBatchmates(username , password);
    }
}
