package Feedback_System;

import Feedback_System.controller.Controller;

import java.util.Scanner;

public class UI {
    public static void main(String[] args) {
        Controller userController = new Controller();
        HelperClass helper = new HelperClass();
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;
        boolean checkSignUpAndSignIn = false;
        String userRole = "";

        while (!exit) {
            System.out.println("------> Feedback System Menu <------");
            if (!checkSignUpAndSignIn) {
                System.out.println("1. Sign Up");
                System.out.println("2. Sign In");
                System.out.println("14. Exit");
            } else {
                if ("admin".equals(userRole)) {
                    System.out.println("3. Create Batch");
                    System.out.println("4. Assign Batch");
                    System.out.println("5. Create Question");
                    System.out.println("6. Update Question");
                    System.out.println("7. Delete Question");
                    System.out.println("9. List Questions");
                    System.out.println("10. List Feedback");
                    System.out.println("11. Feedback by Batch");
                    System.out.println("12. Feedback by Batch for Admin");
                    System.out.println("13. Individual Feedback for Admin");
                } else if ("student".equals(userRole)) {
                    System.out.println("8. Submit Feedback");
                    System.out.println("9. List Questions");
                }
                System.out.println("14. Exit");
            }
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter username: ");
                    String username = scanner.nextLine();
                    System.out.print("Enter password: ");
                    String password = scanner.nextLine();
                    System.out.print("Enter phone number: ");
                    String phoneNumber = scanner.nextLine();
                    boolean check = helper.checkPhoneNumber(phoneNumber);
                    if (check) {
                        System.out.print("Enter role (student/admin): ");
                        String role = scanner.nextLine();
                        boolean isSignUp = userController.signUp(username, password, phoneNumber, role);
                        if (isSignUp) {
                            System.out.println("Registration Successful");
                        } else {
                            System.out.println("User already exists");
                        }
                    } else {
                        System.out.println("Invalid phone number");
                    }
                    break;
                case 2:
                    if (!checkSignUpAndSignIn) {
                        System.out.print("Enter your name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter your password: ");
                        String pass = scanner.nextLine();
                        boolean isSignIn = userController.signIn(name, pass);
                        if (isSignIn) {
                            System.out.println("Login Successful");
                            checkSignUpAndSignIn = true;
//                            userRole = userController.getUserRole(name); // Assume you have a method to get the user role
                        } else {
                            System.out.println("Invalid credentials");
                        }
                    } else {
                        System.out.println("Invalid option. Please try again.");
                    }
                    break;
                case 3:
                    if ("admin".equals(userRole)) {
                        System.out.print("Enter admin phone number: ");
                        String adminPhoneForBatch = scanner.nextLine();
                        System.out.print("Enter batch name: ");
                        String batchName = scanner.nextLine();
                        System.out.println(userController.createBatch(adminPhoneForBatch, batchName));
                    } else {
                        System.out.println("Invalid option. Please try again.");
                    }
                    break;
                case 4:
                    if ("admin".equals(userRole)) {
                        System.out.print("Enter batch name: ");
                        String batchNameForAssign = scanner.nextLine();
                        System.out.print("Enter student phone number: ");
                        String studentPhone = scanner.nextLine();
                        System.out.print("Enter role: ");
                        String adminRole = scanner.nextLine();
                        System.out.print("Enter admin phone number: ");
                        String adminPhoneForAssign = scanner.nextLine();
                        System.out.println(userController.assignBatch(batchNameForAssign, studentPhone, adminRole, adminPhoneForAssign));
                    } else {
                        System.out.println("Invalid option. Please try again.");
                    }
                    break;
                case 5:
                    if ("admin".equals(userRole)) {
                        System.out.print("Enter batch name: ");
                        String batchNameForQuestion = scanner.nextLine();
                        System.out.print("Enter admin phone number: ");
                        String adminPhoneForQuestion = scanner.nextLine();
                        System.out.println(userController.createQuestion(batchNameForQuestion, adminPhoneForQuestion));
                    } else {
                        System.out.println("Invalid option. Please try again.");
                    }
                    break;
                case 6:
                    if ("admin".equals(userRole)) {
                        System.out.print("Enter question ID: ");
                        String qid = scanner.nextLine();
                        System.out.print("Enter batch name: ");
                        String batch = scanner.nextLine();
                        System.out.print("Enter admin phone number: ");
                        String admin = scanner.nextLine();
                        System.out.println(userController.updateQuestion(qid, batch, admin));
                    } else {
                        System.out.println("Invalid option. Please try again.");
                    }
                    break;
                case 7:
                    if ("admin".equals(userRole)) {
                        System.out.print("Enter question ID: ");
                        String qID = scanner.nextLine();
                        System.out.print("Enter batch name: ");
                        String batchN = scanner.nextLine();
                        System.out.print("Enter admin phone number: ");
                        String adPhone = scanner.nextLine();
                        System.out.println(userController.deleteQuestion(qID, batchN, adPhone));
                    } else {
                        System.out.println("Invalid option. Please try again.");
                    }
                    break;
                case 8:
                    if ("student".equals(userRole)) {
                        System.out.print("Enter student phone number: ");
                        String studentPhoneForFeedback = scanner.nextLine();
                        System.out.print("Enter batch name: ");
                        String batchNameForFeedback = scanner.nextLine();
                        System.out.println(userController.submitFeedback(studentPhoneForFeedback, batchNameForFeedback));
                    } else {
                        System.out.println("Invalid option. Please try again.");
                    }
                    break;
                case 9:
                    if (checkSignUpAndSignIn) {
                        userController.questionList();
                    } else {
                        System.out.println("Please sign up or sign in first.");
                    }
                    break;
                case 10:
                    if ("admin".equals(userRole)) {
                        userController.feedbackList();
                    } else {
                        System.out.println("Invalid option. Please try again.");
                    }
                    break;
                case 11:
                    if ("admin".equals(userRole)) {
                        System.out.print("Enter batch name: ");
                        String batchNameForFeedbackByBatch = scanner.nextLine();
                        System.out.println(userController.feedbackByBatch(batchNameForFeedbackByBatch));
                    } else {
                        System.out.println("Invalid option. Please try again.");
                    }
                    break;
                case 12:
                    if ("admin".equals(userRole)) {
                        System.out.print("Enter admin phone number: ");
                        String adminPhoneForFeedbackByBatch = scanner.nextLine();
                        System.out.print("Enter batch name: ");
                        String batchNameForFeedbackByBatchToAdmin = scanner.nextLine();
                        System.out.println(userController.feedbackByBatchToAdmin(adminPhoneForFeedbackByBatch, batchNameForFeedbackByBatchToAdmin));
                    } else {
                        System.out.println("Invalid option. Please try again.");
                    }
                    break;
                case 13:
                    if ("admin".equals(userRole)) {
                        System.out.print("Enter admin phone number: ");
                        String adminPhoneForIndividualFeedback = scanner.nextLine();
                        System.out.print("Enter student phone number: ");
                        String studentPhoneForIndividualFeedback = scanner.nextLine();
                        System.out.println(userController.individualFeedback(adminPhoneForIndividualFeedback, studentPhoneForIndividualFeedback));
                    } else {
                        System.out.println("Invalid option. Please try again.");
                    }
                    break;
                case 14:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }

        scanner.close();
    }
}