package Feedback_System;

import Feedback_System.controller.Controller;

import java.util.Scanner;

public class UIbyPrince {

    public static void main(String[] args) {
        Controller userController = new Controller();
        HelperClass helper = new HelperClass();
        Scanner scanner = new Scanner(System.in);

        int choice = 0;

        while (true) {

            System.out.println("Welcome to Feedback System");
            System.out.println("1. Sign Up");
            System.out.println("2. Sign In");
            System.out.println("14. Exit");

            System.out.println("Enter your choice: ");
            choice = scanner.nextInt();

            if (choice == 1) {
                System.out.print("Enter username: ");
                String username = scanner.nextLine();

                System.out.print("Enter password: ");
                System.out.println("password must be at least 8 characters long, \n     start with an uppercase letter, \n     include at least one lowercase letter, \n     one number,  \n     one special character.");
                String password = scanner.nextLine();
                boolean isValidate = helper.PasswordValidator(password);
                while (!isValidate) {
                    System.out.println("Password is invalid.");
                    System.out.println("Create strong password as per credentials");
                    password = scanner.nextLine();
                    isValidate = helper.PasswordValidator(password);
                }

                System.out.print("Enter phone number: ");
                String phoneNumber = scanner.nextLine();
                boolean checkPhoneNumberValidation = helper.checkPhoneNumber(phoneNumber);
                if (checkPhoneNumberValidation) {
                    System.out.print("Enter role in lower case (student/admin): ");
                    String role = scanner.nextLine();
                    boolean isSignUp = userController.signUp(username, password, phoneNumber, role);
                    if (isSignUp) {
                        System.out.println("Registration Successful");
                    } else {
                        System.out.println("User already exists");
                    }
                } else {
                    System.out.println("Invalid phone number");
                }
                break;
            }

            else if(choice == 2) {
                System.out.print("Enter username: ");
                String username = scanner.nextLine();
                System.out.print("Enter password: ");
                String password = scanner.nextLine();
                boolean isSignIn = userController.signIn(username, password);
                if (isSignIn) {
                    System.out.println("Login Successful");

                    while (true) {
                        String checkRole = userController.getUserRole(username , password);

                        if (checkRole == "student") {
                            System.out.println("1. Know your batch");
                            System.out.println("2. Know your batchmates");
                            System.out.println("3. List Questions");
                            System.out.println("4. Submit Feedback");
                            System.out.println("5. Sign Out");
                            System.out.println("6. Exit");

                            System.out.println("Enter choice : ");
                            choice = scanner.nextInt();
                            if (choice == 1) {
                                String getBatch = userController.getBatchByUsernameAndPassword(username , password);
                                System.out.println("You are assined in batch " + getBatch);
                            }

                            else if (choice == 2) {
                                userController.showMyBatchmates(username , password);
                            }
                        }


                        if (checkRole == "admin") {

                        }

                        else {
                            System.out.println("Invalid role");
                        }
                    }







                }
                else {
                    System.out.println("Invalid username or password");
                }
            }

            else if (choice == 14) {
                return;
            }

            else {
                System.out.println("Invalid choice");
            }
        }














    }
}
