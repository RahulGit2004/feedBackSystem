package Feedback_System.repository.repository;

import Feedback_System.model.Batch;

public interface BatchRepo {
    Batch addNewBatch(Batch batch);
    Batch saveBatchWithStudent(Batch batch);
    Batch duplicateStudent(String studentPhone, String batchName);
    Batch checkBatch(String batchName);
    Batch isStudentByBatch(String batchName, String studentPhone);

    String  getBatchByUsernameAndPassword(String username, String password);


    void showMyBatchmates(String username, String password);
}
