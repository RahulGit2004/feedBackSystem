package Feedback_System.repository.repository.impl;

import Feedback_System.model.User;
import Feedback_System.repository.UserRepo;

import java.util.ArrayList;
import java.util.List;

public class UserRepoImpl implements UserRepo {
    List<User> userList = new ArrayList<>();
    @Override
    public User saveStudent(User user) {
        userList.add(user);
        return user;
    }


    @Override
    public User findUser(String username, String pass) {
        for (User user : userList) {
            if (user.getUsername().equals(username) && user.getPassword().equals(pass)){
                System.out.println(user.getRole());
                return user;
            }
        }
        return null;
    }

    @Override
    public User existsStudent(String studentPhone) {
        for (User user : userList){
            if (user.getPhoneNumber().equals(studentPhone)){
                return user;
            }
        }
        return null;
    }

    @Override
    public List<User> userList() {
        return userList;
    }

    @Override
    public User checkAdminByPhone(String adminPhone) {
        for (User admin:userList){
            if (admin.getPhoneNumber().equals(adminPhone) && (admin.getRole()).toUpperCase().equals("ADMIN")) {
                return admin;
            }
        }
        return null;
    }


    @Override
    public String getRole(String name, String phone) {
        for (User user : userList){
            if (user.getPhoneNumber().equals(phone)) {
                return user.getRole();
            }
        }
        return null;
    }




}
