package Feedback_System.repository.repository.impl;

import Feedback_System.model.Batch;
import Feedback_System.model.User;
import Feedback_System.repository.BatchRepo;

import java.util.ArrayList;
import java.util.List;

public class BatchRepoImpl implements BatchRepo {

    List<Batch> batches = new ArrayList<>();
    List<Batch> batchWithStudent = new ArrayList<>();
    @Override
    public Batch addNewBatch(Batch batch) {
        batches.add(batch);
        return batch;
    }
    @Override
    public Batch saveBatchWithStudent(Batch batch) {
        batchWithStudent.add(batch);
        return batch;
    }
    @Override
    public Batch findBatchByBatchName(String batchName) {
        for (Batch batch: batches) {
            if (batch.getBatchName().equals(batchName)) {
                return batch;
            }
        }
        return null;
    }

    @Override
    public List<Batch> listOfBatchWithStudent() {
        return batchWithStudent;
    }

    @Override
    public List<Batch> listOfBatch() {
        return batches;
    }

    @Override
    public boolean existsBatch(String batchName) {
        for (Batch batch : batches) {
            if (batch.getBatchName().equals(batchName)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void deleteBatch(String batchName) {
        batches.removeIf(batch -> batch.getBatchName().equals(batchName));
        batchWithStudent.removeIf(batch -> batch.getBatchName().equals(batchName));
    }

    public String findBatchByUsernameAndPassword(String username , String password){
        for (Batch batch :batchWithStudent) {
            List<User> students = batch.getStudentsList();
            for (User user : students) {
                if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                    return batch.getBatchName();
                }
            }
        }
        return null;
    }


    public List showBatchMates(String batchName) {
        List<String> batchmates = new ArrayList<>();
        for (Batch batch : batchWithStudent) {
            if (batch.getBatchName().equals(batchName)) {
                List<User> students = batch.getStudentsList();
                for (User user : students) {
                    batchmates.add(user.getUsername());
                    batchmates.add(user.getPhoneNumber());
                }
            }
        }
        return batchmates;
    }


    public boolean isBatchExists(){
        return batches.size()>0;
    }










}