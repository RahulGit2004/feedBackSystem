package Feedback_System.repository;

import Feedback_System.model.Batch;

import java.util.List;

public interface BatchRepo {
    Batch addNewBatch(Batch batch);
    Batch saveBatchWithStudent(Batch batch);
    Batch findBatchByBatchName(String batchName);
    //    Batch isStudentByBatch(String batchName, String studentPhone);
    List listOfBatchWithStudent();

    List<Batch> listOfBatch();

    boolean existsBatch(String batchNameForAssign);

    void deleteBatch(String batchName);
}
