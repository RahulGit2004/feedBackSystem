package Feedback_System.controller;

import Feedback_System.service.impl.BatchServiceImpl;

public class BatchController {
    BatchServiceImpl batchService = new BatchServiceImpl();



//    public Batch createBatch(String batchName, String studentName, String studentPhone, String role, String adminPhone) {
//        return batchService.createBatch(batchName, studentName, studentPhone,role,adminPhone,studentService);
//    }
}
