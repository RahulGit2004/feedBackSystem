package Feedback_System.repository;

import Feedback_System.model.User;

import java.util.List;

public interface UserRepo {
    User saveUser(User user);


    User findUserByPhoneAndPassword(String username, String pass);
    User findStudentByPhone(String studentPhone);
    List<User> listOfUser();

    User findAdminByPhone(String adminPhone);
    List<User> studentData(String studentPhonenumber);
}
