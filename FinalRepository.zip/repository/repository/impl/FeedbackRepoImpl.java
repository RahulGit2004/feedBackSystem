package Feedback_System.repository.impl;

import Feedback_System.model.StudentFeedback;
import Feedback_System.repository.FeedbackRepo;

import java.util.ArrayList;
import java.util.List;

public class FeedbackRepoImpl implements FeedbackRepo {
    List<StudentFeedback> feedbackList = new ArrayList<>();
    @Override
    public StudentFeedback saveFeedback(StudentFeedback feedback) {
        feedbackList.add(feedback);
        return feedback;
    }

    @Override
    public List<StudentFeedback> feedbackList() {
        return feedbackList;
    }

//    @Override
//    public boolean alreadyFeedbackProvidedByStudent(String phone, String qId) {
//        for (StudentFeedback feedback: feedbackList) {
//            if (feedback.getStudentPhone().equals(phone) && feedback.getFeedbackQid().equals(qId)){
//                return false;
//            }
//        }
//        return true;
//    }


    @Override
    public List<String> feedbackByPhoneNumber(String studentPhone) {
        List<String> feedbacks  = new ArrayList<>();
        for (StudentFeedback feedback: feedbackList) {
                if (feedback.getStudentPhone().equals(studentPhone)) {
                    boolean active = feedback.getFlag();
                    if (active) {
                    feedbacks.add(feedback.getFeedbackDetails());
                }
            }
        }
        return feedbacks;
    }

    @Override
    public StudentFeedback deleteFeedbackByBatch(String batch, String qId) {
        for (StudentFeedback feedback: feedbackList) { // updated here
            if (feedback.getBatchName().equals(batch) && feedback.getqId().equals(qId)) {
                feedback.setFlag(false); // completely done (this would help me to do not remove my feedback data)
                return feedback;
            }
        }
        return null;
    }


}
